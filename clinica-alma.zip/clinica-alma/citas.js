(function () {
    const date = document.getElementById('cita-fecha');
    const time = document.getElementById('cita-hora');
    const message = document.getElementById('cita-disponibilidad');
    if (!date || !time || !message) return;

    let request = 0;
    function reset(text) {
        time.replaceChildren(new Option(text, ''));
        time.disabled = true;
    }
    date.addEventListener('change', async function () {
        const current = ++request;
        reset('Consultando horarios...');
        message.textContent = '';
        if (!date.value) {
            reset('Selecciona una fecha primero');
            return;
        }
        try {
            const url = new URL(almaCitas.url);
            url.searchParams.set('action', 'alma_disponibilidad');
            url.searchParams.set('fecha', date.value);
            const response = await fetch(url);
            const result = await response.json();
            if (current !== request) return;
            if (!response.ok || !result.success) {
                reset('No se pudieron cargar los horarios');
                message.textContent = result.data && result.data.message ? result.data.message : 'Inténtalo nuevamente.';
                return;
            }
            if (!result.data.slots.length) {
                reset('Sin horarios disponibles');
                message.textContent = 'Elige otra fecha para consultar disponibilidad.';
                return;
            }
            reset('Selecciona un horario');
            result.data.slots.forEach(function (slot) {
                time.add(new Option(slot, slot));
            });
            time.disabled = false;
        } catch (error) {
            if (current !== request) return;
            reset('No se pudieron cargar los horarios');
            message.textContent = 'No se pudo consultar la disponibilidad. Inténtalo nuevamente.';
        }
    });
})();
