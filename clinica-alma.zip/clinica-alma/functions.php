<?php
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('clinica-alma', get_stylesheet_uri(), array(), '1.2');
    if (is_front_page()) {
        wp_enqueue_script('clinica-alma-citas', get_theme_file_uri('citas.js'), array(), '1.0', true);
        wp_localize_script('clinica-alma-citas', 'almaCitas', array('url' => admin_url('admin-ajax.php')));
    }
});

add_action('init', function () {
    register_post_type('alma_solicitud', array(
        'labels' => array('name' => 'Solicitudes', 'singular_name' => 'Solicitud'),
        'public' => false,
        'show_ui' => true,
        'menu_icon' => 'dashicons-email-alt',
        'supports' => array('title', 'editor'),
        'capability_type' => 'post',
    ));
});

function alma_reception_page() {
    $page = get_page_by_path('recepcion-citas');
    if (!$page || $page->post_status !== 'publish' || get_page_template_slug($page->ID) !== 'recepcion-citas.php') {
        return null;
    }
    return $page;
}

function alma_setup_reception_page() {
    if (get_page_by_path('recepcion-citas')) {
        return;
    }
    $page = wp_insert_post(array(
        'post_type' => 'page',
        'post_status' => 'publish',
        'post_title' => 'Recepción de citas',
        'post_name' => 'recepcion-citas',
        'meta_input' => array('_wp_page_template' => 'recepcion-citas.php'),
    ), true);
    if (is_wp_error($page) || !$page || !alma_reception_page()) {
        error_log('Clínica Alma: no se pudo crear la página de recepción.');
    }
}
add_action('after_switch_theme', 'alma_setup_reception_page');

// Cubre instalaciones donde el tema ya estaba activo (actualización o reemplazo del ZIP).
add_action('init', function () {
    if (get_option('alma_recepcion_setup') !== '1') {
        alma_setup_reception_page();
        update_option('alma_recepcion_setup', '1');
    }
}, 20);

function alma_reception_url() {
    $page = alma_reception_page();
    return $page ? get_permalink($page) : home_url('/?pagename=recepcion-citas');
}

add_action('admin_notices', function () {
    if (!current_user_can('manage_options') || alma_reception_page()) {
        return;
    }
    echo '<div class="notice notice-error"><p>Clínica Alma: la página de recepción falta, no está publicada o no usa la plantilla «Recepción de citas». Revisa <a href="' . esc_url(admin_url('edit.php?post_type=page')) . '">Páginas</a>. Si el slug «recepcion-citas» ya pertenece a otra página, no se ha modificado.</p></div>';
});

add_action('admin_menu', function () {
    add_options_page('Acceso de recepción', 'Acceso de recepción', 'manage_options', 'alma-recepcion', 'alma_recepcion_settings_page');
});

function alma_recepcion_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('No tienes permisos para administrar el acceso.', '', array('response' => 403));
    }
    $result = isset($_GET['resultado']) && is_string($_GET['resultado']) ? sanitize_key(wp_unslash($_GET['resultado'])) : '';
    ?>
    <div class="wrap">
        <h1>Acceso de recepción</h1>
        <p>Configura la contraseña de la cuenta independiente que consulta las citas. El usuario es <strong>recepcion</strong>.</p>
        <p>Estado: <strong><?php echo get_option('alma_recepcion_password_hash') ? 'Contraseña configurada' : 'Pendiente de configuración'; ?></strong>.</p>
        <?php if ($result === 'guardado') : ?>
            <div class="notice notice-success"><p>Contraseña guardada. Las sesiones anteriores de recepción se han cerrado.</p></div>
        <?php elseif ($result === 'invalido') : ?>
            <div class="notice notice-error"><p>Las contraseñas deben coincidir y tener al menos 12 caracteres y como máximo 72 bytes.</p></div>
        <?php elseif ($result === 'error') : ?>
            <div class="notice notice-error"><p>No se pudo guardar la contraseña. Inténtalo nuevamente.</p></div>
        <?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="alma_guardar_recepcion">
            <?php wp_nonce_field('alma_guardar_recepcion'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row"><label for="alma-clave">Nueva contraseña</label></th><td><input class="regular-text" id="alma-clave" name="clave" type="password" minlength="12" maxlength="72" autocomplete="new-password" required><p class="description">Usa una contraseña única de al menos 12 caracteres y hasta 72 bytes.</p></td></tr>
                <tr><th scope="row"><label for="alma-confirmacion">Repetir contraseña</label></th><td><input class="regular-text" id="alma-confirmacion" name="confirmacion" type="password" minlength="12" maxlength="72" autocomplete="new-password" required></td></tr>
            </table>
            <?php submit_button('Guardar contraseña'); ?>
        </form>
        <?php $reception = alma_reception_page(); if ($reception) : ?>
            <p><a href="<?php echo esc_url(get_permalink($reception)); ?>">Abrir acceso de recepción</a></p>
        <?php endif; ?>
    </div>
    <?php
}

function alma_guardar_recepcion() {
    if (!current_user_can('manage_options')) {
        wp_die('No tienes permisos para administrar el acceso.', '', array('response' => 403));
    }
    check_admin_referer('alma_guardar_recepcion');
    $password = isset($_POST['clave']) && is_string($_POST['clave']) ? wp_unslash($_POST['clave']) : '';
    $confirmation = isset($_POST['confirmacion']) && is_string($_POST['confirmacion']) ? wp_unslash($_POST['confirmacion']) : '';
    $result = 'invalido';
    if ($password === $confirmation && mb_strlen($password, 'UTF-8') >= 12 && strlen($password) <= 72 && strpos($password, "\0") === false) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        if ($hash !== false) {
            update_option('alma_recepcion_password_hash', $hash, false);
            $result = get_option('alma_recepcion_password_hash') === $hash ? 'guardado' : 'error';
        } else {
            $result = 'error';
        }
        if ($result === 'error') {
            error_log('Clínica Alma: no se pudo guardar la contraseña de recepción.');
        }
    }
    wp_safe_redirect(add_query_arg(array('page' => 'alma-recepcion', 'resultado' => $result), admin_url('options-general.php')));
    exit;
}
add_action('admin_post_alma_guardar_recepcion', 'alma_guardar_recepcion');

add_action('template_redirect', function () {
    if (!is_page_template('recepcion-citas.php')) {
        return;
    }
    nocache_headers();
    header('X-Robots-Tag: noindex, nofollow', true);
    if (session_status() !== PHP_SESSION_ACTIVE) {
        ini_set('session.use_strict_mode', '1');
        session_name('ALMARECEPCION');
        session_set_cookie_params(array(
            'path' => '/',
            'secure' => is_ssl(),
            'httponly' => true,
            'samesite' => 'Strict',
        ));
        if (!session_start()) {
            error_log('Clínica Alma: no se pudo iniciar la sesión de recepción.');
            wp_die('No se pudo iniciar la sesión. Inténtalo más tarde.', '', array('response' => 500));
        }
    }
    if (empty($_SESSION['alma_csrf'])) {
        $_SESSION['alma_csrf'] = bin2hex(random_bytes(32));
    }

    $password_hash = get_option('alma_recepcion_password_hash', '');
    $authenticated = is_string($password_hash) && $password_hash !== ''
        && isset($_SESSION['alma_hash'], $_SESSION['alma_last_activity'])
        && is_string($_SESSION['alma_hash'])
        && hash_equals(hash('sha256', $password_hash), $_SESSION['alma_hash'])
        && time() - (int) $_SESSION['alma_last_activity'] <= 1800;
    if (!$authenticated) {
        unset($_SESSION['alma_hash'], $_SESSION['alma_last_activity']);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recepcion_action']) && is_string($_POST['recepcion_action'])) {
        $action = sanitize_key(wp_unslash($_POST['recepcion_action']));
        $csrf = isset($_POST['recepcion_csrf']) && is_string($_POST['recepcion_csrf']) ? wp_unslash($_POST['recepcion_csrf']) : '';
        if (!hash_equals($_SESSION['alma_csrf'], $csrf)) {
            wp_die('La sesión del formulario ha caducado. Recarga la página e inténtalo nuevamente.', '', array('response' => 403));
        }
        if ($action === 'salir' && $authenticated) {
            unset($_SESSION['alma_hash'], $_SESSION['alma_last_activity']);
            if (!session_regenerate_id(true)) {
                error_log('Clínica Alma: no se pudo renovar la sesión de recepción.');
                wp_die('No se pudo cerrar la sesión. Inténtalo nuevamente.', '', array('response' => 500));
            }
            $_SESSION['alma_csrf'] = bin2hex(random_bytes(32));
            wp_safe_redirect(get_permalink());
            exit;
        }
        if ($action === 'entrar' && !$authenticated && $password_hash) {
            $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'desconocida';
            $limit_key = 'alma_login_' . substr(wp_hash($ip), 0, 32);
            $attempts = (int) get_transient($limit_key);
            $username = isset($_POST['usuario']) && is_string($_POST['usuario']) ? wp_unslash($_POST['usuario']) : '';
            $password = isset($_POST['clave']) && is_string($_POST['clave']) ? wp_unslash($_POST['clave']) : '';
            if ($attempts >= 5) {
                $GLOBALS['alma_recepcion_error'] = 'Demasiados intentos. Espera 15 minutos antes de volver a intentarlo.';
            } elseif (strlen($password) <= 72 && password_verify($password, $password_hash) && hash_equals('recepcion', $username)) {
                delete_transient($limit_key);
                if (!session_regenerate_id(true)) {
                    error_log('Clínica Alma: no se pudo renovar la sesión de recepción.');
                    wp_die('No se pudo iniciar la sesión. Inténtalo nuevamente.', '', array('response' => 500));
                }
                $_SESSION['alma_hash'] = hash('sha256', $password_hash);
                $_SESSION['alma_last_activity'] = time();
                $_SESSION['alma_csrf'] = bin2hex(random_bytes(32));
                wp_safe_redirect(get_permalink());
                exit;
            } else {
                set_transient($limit_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
                $GLOBALS['alma_recepcion_error'] = 'Usuario o contraseña incorrectos.';
            }
        }
    }
    if (!$authenticated) {
        require get_theme_file_path('login-recepcion.php');
        exit;
    }
    $_SESSION['alma_last_activity'] = time();
});

function alma_slots_table() {
    global $wpdb;
    return $wpdb->prefix . 'alma_horarios';
}

add_action('init', function () {
    if (get_option('alma_horarios_version') === '1') {
        return;
    }
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table = alma_slots_table();
    $charset = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE $table (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        solicitud_id bigint(20) unsigned NOT NULL,
        horario datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY horario (horario),
        UNIQUE KEY solicitud_id (solicitud_id)
    ) $charset;");
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table) {
        update_option('alma_horarios_version', '1');
    } else {
        error_log('Clínica Alma: no se pudo crear la tabla de horarios.');
    }
}, 20);

function alma_day_slots($date) {
    $day = DateTimeImmutable::createFromFormat('!Y-m-d', $date, wp_timezone());
    if (!$day || $day->format('Y-m-d') !== $date || $date < wp_date('Y-m-d')) {
        return new WP_Error('fecha', 'Selecciona una fecha válida.');
    }
    $weekday = (int) $day->format('N');
    if ($weekday === 7) {
        return array();
    }
    $start = $weekday === 6 ? 9 : 8;
    $end = $weekday === 6 ? 13 : 19;
    $now = current_datetime();
    $slots = array();
    for ($minutes = $start * 60; $minutes < $end * 60; $minutes += 30) {
        $time = sprintf('%02d:%02d', intdiv($minutes, 60), $minutes % 60);
        if ($day->setTime(intdiv($minutes, 60), $minutes % 60) > $now) {
            $slots[] = $time;
        }
    }
    return $slots;
}

function alma_available_slots($date) {
    $slots = alma_day_slots($date);
    if (is_wp_error($slots) || !$slots) {
        return $slots;
    }
    global $wpdb;
    $table = alma_slots_table();
    $occupied = $wpdb->get_col($wpdb->prepare(
        "SELECT horario FROM $table WHERE horario >= %s AND horario < %s",
        $date . ' 00:00:00',
        $date . ' 23:59:59'
    ));
    if ($wpdb->last_error) {
        error_log('Clínica Alma: no se pudo consultar la disponibilidad.');
        return new WP_Error('disponibilidad', 'No se pudo consultar la disponibilidad.');
    }
    $occupied = array_map(function ($slot) {
        return substr($slot, 11, 5);
    }, $occupied);
    return array_values(array_diff($slots, $occupied));
}

function alma_get_availability() {
    $date = isset($_GET['fecha']) ? sanitize_text_field(wp_unslash($_GET['fecha'])) : '';
    $slots = alma_available_slots($date);
    if (is_wp_error($slots)) {
        wp_send_json_error(array('message' => $slots->get_error_message()), 400);
    }
    wp_send_json_success(array('slots' => $slots));
}
add_action('wp_ajax_nopriv_alma_disponibilidad', 'alma_get_availability');
add_action('wp_ajax_alma_disponibilidad', 'alma_get_availability');

add_action('deleted_post', function ($post_id, $post) {
    if ($post->post_type !== 'alma_solicitud') {
        return;
    }
    global $wpdb;
    if ($wpdb->delete(alma_slots_table(), array('solicitud_id' => $post_id), array('%d')) === false) {
        error_log('Clínica Alma: no se pudo liberar el horario de una solicitud eliminada.');
    }
}, 10, 2);

function alma_form_notice($form) {
    if (!isset($_GET['form'], $_GET['resultado']) || sanitize_key(wp_unslash($_GET['form'])) !== $form) {
        return;
    }
    $result = sanitize_key(wp_unslash($_GET['resultado']));
    if ($result === 'ok') {
        $message = $form === 'cita'
            ? 'Tu solicitud se guardó y el horario quedó bloqueado. Es una demostración: la cita no está confirmada y no se envía ninguna notificación.'
            : 'Tu solicitud se guardó correctamente. Es una demostración: no se enviará ningún mensaje.';
        echo '<div class="notice" role="status">' . esc_html($message) . '</div>';
    } elseif ($result === 'error') {
        echo '<div class="notice notice-error" role="alert">No se pudo guardar la solicitud. Revisa los campos e inténtalo nuevamente.</div>';
    } elseif ($result === 'ocupado') {
        echo '<div class="notice notice-error" role="alert">Ese horario ya no está disponible. Selecciona otro y vuelve a enviar la solicitud.</div>';
    }
}

function alma_handle_form() {
    $form = isset($_POST['form_type']) ? sanitize_key(wp_unslash($_POST['form_type'])) : '';
    if (!in_array($form, array('cita', 'contacto'), true)) {
        wp_die('Formulario no válido.', '', array('response' => 400));
    }
    $redirect = home_url('/#' . ($form === 'cita' ? 'citas' : 'contacto'));
    $fail = function ($result = 'error') use ($redirect, $form) {
        wp_safe_redirect(add_query_arg(array('form' => $form, 'resultado' => $result), $redirect));
        exit;
    };
    if (!isset($_POST['alma_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['alma_nonce'])), 'alma_' . $form)) {
        $fail();
    }
    $name = isset($_POST['nombre']) ? sanitize_text_field(wp_unslash($_POST['nombre'])) : '';
    $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $phone = isset($_POST['telefono']) ? sanitize_text_field(wp_unslash($_POST['telefono'])) : '';
    if (!$name || mb_strlen($name) > 100 || !is_email($email) || strlen($email) > 254 || mb_strlen($phone) > 30) {
        $fail();
    }
    $content = "Nombre: $name\nCorreo: $email\nTeléfono: $phone";
    if ($form === 'cita') {
        $services = array('Medicina general', 'Pediatría', 'Nutrición', 'Bienestar emocional');
        $service = isset($_POST['servicio']) ? sanitize_text_field(wp_unslash($_POST['servicio'])) : '';
        $date = isset($_POST['fecha']) ? sanitize_text_field(wp_unslash($_POST['fecha'])) : '';
        $time = isset($_POST['hora']) ? sanitize_text_field(wp_unslash($_POST['hora'])) : '';
        $slots = alma_day_slots($date);
        if (!in_array($service, $services, true) || is_wp_error($slots) || !in_array($time, $slots, true)) {
            $fail();
        }
        $content .= "\nServicio: $service\nFecha: $date\nHorario: $time";
    } else {
        $message = isset($_POST['mensaje']) ? sanitize_textarea_field(wp_unslash($_POST['mensaje'])) : '';
        if (!$message || mb_strlen($message) > 2000) {
            $fail();
        }
        $content .= "\nMensaje:\n$message";
    }
    $post = wp_insert_post(array(
        'post_type' => 'alma_solicitud',
        'post_status' => 'private',
        'post_title' => ($form === 'cita' ? 'Cita' : 'Contacto') . ' - ' . $name,
        'post_content' => $content,
    ), true);
    if (is_wp_error($post) || !$post) {
        $fail();
    }
    if ($form === 'cita') {
        global $wpdb;
        $saved = $wpdb->insert(alma_slots_table(), array(
            'solicitud_id' => $post,
            'horario' => $date . ' ' . $time . ':00',
        ), array('%d', '%s'));
        if ($saved === false) {
            $available = alma_available_slots($date);
            if (!wp_delete_post($post, true)) {
                error_log('Clínica Alma: no se pudo eliminar una solicitud cuyo horario no se guardó.');
            }
            if (!is_wp_error($available) && !in_array($time, $available, true)) {
                $fail('ocupado');
            }
            error_log('Clínica Alma: no se pudo guardar el horario solicitado.');
            $fail();
        }
    }
    wp_safe_redirect(add_query_arg(array('form' => $form, 'resultado' => 'ok'), $redirect));
    exit;
}
add_action('admin_post_nopriv_alma_form', 'alma_handle_form');
add_action('admin_post_alma_form', 'alma_handle_form');

add_theme_support('title-tag');
