<?php get_header(); ?>
<main id="contenido">
    <section class="hero" id="inicio">
        <div class="hero-grid">
            <div class="hero-copy">
                <div class="eyebrow">Tu bienestar, nuestra prioridad</div>
                <h1>La salud se cuida <em>mejor juntos.</em></h1>
                <p>En Clínica Alma creemos en una atención cercana, humana y diseñada para acompañarte en cada etapa de tu vida.</p>
                <div class="actions"><a class="button" href="#citas">Solicitar una cita <span aria-hidden="true">↗</span></a><a class="button button-light" href="#servicios">Conoce nuestros servicios <span aria-hidden="true">→</span></a></div>
            </div>
            <div class="hero-image" role="img" aria-label="Espacio luminoso de una clínica"></div>
        </div>
    </section>
    <div class="trust"><div class="wrap trust-inner">
        <div class="trust-item"><div class="trust-icon" aria-hidden="true">♡</div><div><strong>Atención con empatía</strong><span>Te escuchamos en cada visita</span></div></div>
        <div class="trust-item"><div class="trust-icon" aria-hidden="true">✳</div><div><strong>Un equipo para ti</strong><span>Distintas especialidades, un mismo cuidado</span></div></div>
        <div class="trust-item"><div class="trust-icon" aria-hidden="true">◷</div><div><strong>Siempre cerca</strong><span>Un espacio pensado para tu bienestar</span></div></div>
    </div></div>

    <section class="section" id="servicios"><div class="wrap">
        <div class="section-heading"><div><div class="eyebrow">Cuidamos de ti</div><h2>Una atención para cada<br>momento de tu vida.</h2><p>Un enfoque integral que pone a las personas en el centro, con servicios pensados para acompañarte.</p></div><a class="text-link" href="#citas">Solicitar una cita →</a></div>
        <div class="services">
            <article class="service"><div class="service-icon" aria-hidden="true">✚</div><h3>Medicina general</h3><p>Consultas preventivas, seguimiento de salud y orientación para tus necesidades cotidianas.</p></article>
            <article class="service"><div class="service-icon" aria-hidden="true">♡</div><h3>Pediatría</h3><p>Acompañamiento respetuoso para el crecimiento y bienestar de los más pequeños.</p></article>
            <article class="service"><div class="service-icon" aria-hidden="true">✿</div><h3>Nutrición</h3><p>Orientación personalizada para construir hábitos de alimentación saludables y sostenibles.</p></article>
            <article class="service"><div class="service-icon" aria-hidden="true">☼</div><h3>Bienestar emocional</h3><p>Un espacio de escucha y apoyo para cuidar también de tu salud emocional.</p></article>
        </div>
    </div></section>

    <section class="section section-white" id="nosotros"><div class="wrap about-grid">
        <div class="about-photo"><img src="<?php echo esc_url(get_theme_file_uri('assets/espacio.jpg')); ?>" alt="Espacio cálido y luminoso para la atención"><div class="photo-note"><strong>Para sentirte bien</strong>Un espacio pensado para ti</div></div>
        <div class="about-copy"><div class="eyebrow">Nuestra esencia</div><h2>Una forma más humana de cuidar.</h2><p>Clínica Alma nació de una idea sencilla: la salud se vive mejor cuando nos sentimos escuchados. Imaginamos un lugar donde la cercanía y el cuidado integral van de la mano.</p><p>Nuestra misión es acompañar a cada persona con respeto, empatía y una mirada que considere su bienestar completo.</p><div class="values"><div class="value"><strong>♡ Cercanía</strong><span>Escucha y trato personal.</span></div><div class="value"><strong>✳ Compromiso</strong><span>Cuidado responsable y respetuoso.</span></div><div class="value"><strong>✚ Integralidad</strong><span>Una mirada que conecta cuerpo y mente.</span></div><div class="value"><strong>☼ Bienestar</strong><span>Pequeños pasos para vivir mejor.</span></div></div><a class="text-link" href="#equipo">Conoce a nuestro equipo →</a></div>
    </div></section>

    <section class="section" id="equipo"><div class="wrap">
        <div class="section-heading"><div><div class="eyebrow">Personas que cuidan personas</div><h2>Conoce a nuestro equipo.</h2><p>Un equipo cercano, comprometido con escucharte y acompañarte. Perfiles y fotografías ilustrativos.</p></div><a class="text-link" href="#citas">Agenda una visita →</a></div>
        <div class="team">
            <article class="member"><img src="<?php echo esc_url(get_theme_file_uri('assets/medica.jpg')); ?>" alt="Fotografía ilustrativa de una profesional de salud"><div class="member-content"><h3>Dra. Lucía Reyes</h3><small>Medicina general</small><p>Promueve el cuidado preventivo y una relación cercana con cada paciente.</p></div></article>
            <article class="member"><img src="<?php echo esc_url(get_theme_file_uri('assets/medico.jpg')); ?>" alt="Fotografía ilustrativa de un profesional de salud"><div class="member-content"><h3>Dr. Martín Vega</h3><small>Pediatría</small><p>Acompaña a las familias con paciencia, escucha y atención en cada etapa.</p></div></article>
            <article class="member"><img src="<?php echo esc_url(get_theme_file_uri('assets/nutricionista.jpg')); ?>" alt="Fotografía ilustrativa de una profesional de salud"><div class="member-content"><h3>Lic. Sofía Morales</h3><small>Nutrición</small><p>Ayuda a crear hábitos realistas desde una mirada amable y personalizada.</p></div></article>
        </div>
    </div></section>

    <section class="section section-soft" id="testimonios"><div class="wrap">
        <div class="section-heading"><div><div class="eyebrow">Historias que inspiran</div><h2>El cuidado se siente.</h2><p>Ejemplos ficticios de testimonios para mostrar cómo se verían las experiencias de pacientes.</p></div></div>
        <div class="reviews">
            <article class="review"><div class="stars" aria-label="5 estrellas">★★★★★</div><blockquote>“Me sentí escuchada desde el primer momento. Un espacio donde el trato cercano hace la diferencia.”</blockquote><small>María P. · Testimonio ficticio</small></article>
            <article class="review"><div class="stars" aria-label="5 estrellas">★★★★★</div><blockquote>“Encontramos un equipo amable que nos acompañó con mucha paciencia y claridad.”</blockquote><small>Andrés M. · Testimonio ficticio</small></article>
            <article class="review"><div class="stars" aria-label="5 estrellas">★★★★★</div><blockquote>“Una experiencia cálida y tranquila. Se nota el cuidado en cada detalle.”</blockquote><small>Camila R. · Testimonio ficticio</small></article>
        </div>
    </div></section>

    <section class="section section-white" id="citas"><div class="wrap booking-grid">
        <div class="booking-copy"><div class="eyebrow">Estamos para acompañarte</div><h2>Tu bienestar puede comenzar hoy.</h2><p>Elige una fecha y un horario disponible de 30 minutos. Al enviar la solicitud el horario quedará bloqueado, pero la cita no estará confirmada y no se enviará ninguna notificación.</p><div class="hours"><strong>Horarios de atención ilustrativos</strong><p>Lunes a viernes · 8:00 a 19:00<br>Sábados · 9:00 a 13:00<br>Domingos · Cerrado</p></div><p>Este sitio es una demostración. No ingreses datos personales o de salud reales. Los festivos no se consideran automáticamente.</p></div>
        <div class="form-card"><h3>Solicita tu cita</h3><p>Todos los campos marcados con * son obligatorios.</p>
            <?php alma_form_notice('cita'); ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="alma_form"><input type="hidden" name="form_type" value="cita"><?php wp_nonce_field('alma_cita', 'alma_nonce'); ?>
                <div class="form-grid"><div class="field"><label for="cita-nombre">Nombre completo *</label><input id="cita-nombre" name="nombre" maxlength="100" required autocomplete="name" placeholder="Tu nombre"></div><div class="field"><label for="cita-telefono">Teléfono</label><input id="cita-telefono" name="telefono" maxlength="30" type="tel" autocomplete="tel" placeholder="Tu teléfono"></div></div>
                <div class="field"><label for="cita-email">Correo electrónico *</label><input id="cita-email" name="email" type="email" maxlength="254" required autocomplete="email" placeholder="tu@correo.com"></div>
                <div class="form-grid"><div class="field"><label for="cita-servicio">Servicio *</label><select id="cita-servicio" name="servicio" required><option value="">Selecciona un servicio</option><option>Medicina general</option><option>Pediatría</option><option>Nutrición</option><option>Bienestar emocional</option></select></div><div class="field"><label for="cita-fecha">Fecha preferida *</label><input id="cita-fecha" name="fecha" type="date" min="<?php echo esc_attr(wp_date('Y-m-d')); ?>" required></div></div>
                <div class="field"><label for="cita-hora">Horario disponible *</label><select id="cita-hora" name="hora" required disabled aria-describedby="cita-disponibilidad"><option value="">Selecciona una fecha primero</option></select><span class="form-note" id="cita-disponibilidad" role="status" aria-live="polite"></span><noscript>Activa JavaScript para consultar los horarios disponibles.</noscript></div>
                <button class="button" type="submit">Enviar solicitud <span aria-hidden="true">↗</span></button><p class="form-note">Solo demostración: no se confirma ninguna cita. No incluyas información médica.</p>
            </form>
        </div>
    </div></section>

    <section class="section" id="contacto"><div class="wrap contact-grid">
        <div class="contact-copy"><div class="eyebrow">Hablemos</div><h2>Estamos cerca de ti.</h2><p>Estos datos son ficticios y se muestran únicamente como ejemplo. El mapa señala el centro de Santiago, no la ubicación de una clínica.</p>
            <div class="contact-list"><div><strong>Dirección de ejemplo</strong><span>Av. Bienestar 123, Santiago, Chile (ficticia)</span></div><div><strong>Teléfono de ejemplo</strong><span>+56 2 0000 0000 (no operativo)</span></div><div><strong>Correo de ejemplo</strong><span>hola@clinica-alma.example (no operativo)</span></div><div><strong>Horario</strong><span>Lunes a viernes de 8:00 a 19:00 · Sábados de 9:00 a 13:00</span></div><div><strong>Redes sociales</strong><a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer">Instagram ↗</a> &nbsp;·&nbsp; <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer">Facebook ↗</a> <span>(enlaces generales)</span></div></div>
            <iframe class="map" title="Mapa de referencia del centro de Santiago" loading="lazy" referrerpolicy="no-referrer" src="https://www.openstreetmap.org/export/embed.html?bbox=-70.660%2C-33.446%2C-70.644%2C-33.434&amp;layer=mapnik"></iframe><small>Mapa de referencia: <a href="https://www.openstreetmap.org/copyright">© OpenStreetMap</a>.</small>
        </div>
        <div class="form-card"><h3>Envíanos un mensaje</h3><p>Para consultas generales. No incluyas datos personales o información médica real.</p>
            <?php alma_form_notice('contacto'); ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="alma_form"><input type="hidden" name="form_type" value="contacto"><?php wp_nonce_field('alma_contacto', 'alma_nonce'); ?>
                <div class="field"><label for="contacto-nombre">Nombre completo *</label><input id="contacto-nombre" name="nombre" maxlength="100" required autocomplete="name" placeholder="Tu nombre"></div>
                <div class="field"><label for="contacto-email">Correo electrónico *</label><input id="contacto-email" name="email" type="email" maxlength="254" required autocomplete="email" placeholder="tu@correo.com"></div>
                <div class="field"><label for="contacto-telefono">Teléfono</label><input id="contacto-telefono" name="telefono" maxlength="30" type="tel" autocomplete="tel" placeholder="Tu teléfono"></div>
                <div class="field"><label for="contacto-mensaje">Mensaje *</label><textarea id="contacto-mensaje" name="mensaje" maxlength="2000" required placeholder="¿En qué podemos ayudarte?"></textarea></div>
                <button class="button" type="submit">Enviar mensaje <span aria-hidden="true">↗</span></button><p class="form-note">El mensaje se guarda en WordPress; no se envía por correo.</p>
            </form>
        </div>
    </div></section>
</main>
<?php get_footer(); ?>
