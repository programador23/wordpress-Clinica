<?php get_header(); ?>
<main id="contenido" class="section">
    <div class="wrap reception-login">
        <div class="eyebrow">Acceso privado</div>
        <h1>Recepción de citas</h1>
        <p>Ingresa con la cuenta de recepción para consultar las solicitudes.</p>
        <div class="form-card">
            <?php if (!get_option('alma_recepcion_password_hash')) : ?>
                <div class="notice notice-error" role="alert">El acceso todavía no está configurado. El responsable del sitio puede <a href="<?php echo esc_url(admin_url('options-general.php?page=alma-recepcion')); ?>">configurar la contraseña</a>.</div>
            <?php else : ?>
                <?php if (!empty($GLOBALS['alma_recepcion_error'])) : ?><div class="notice notice-error" role="alert"><?php echo esc_html($GLOBALS['alma_recepcion_error']); ?></div><?php endif; ?>
                <form method="post" action="<?php echo esc_url(get_permalink()); ?>">
                    <input type="hidden" name="recepcion_action" value="entrar">
                    <input type="hidden" name="recepcion_csrf" value="<?php echo esc_attr($_SESSION['alma_csrf']); ?>">
                    <div class="field"><label for="recepcion-usuario">Usuario</label><input id="recepcion-usuario" name="usuario" autocomplete="username" required></div>
                    <div class="field"><label for="recepcion-clave">Contraseña</label><input id="recepcion-clave" name="clave" type="password" autocomplete="current-password" maxlength="72" required></div>
                    <button class="button" type="submit">Ingresar</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php get_footer(); ?>
