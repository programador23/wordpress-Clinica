Clínica Alma
============

Tema de demostración para WordPress 6.2 o superior, PHP 7.3 o superior con
mbstring, y una base de datos que permita crear tablas. El servidor debe
permitir sesiones PHP. La portada contiene las secciones de inicio, clínica,
equipo, servicios, testimonios, citas y contacto.

Instalación
-----------

1. En Apariencia > Temas, sube el archivo ZIP y activa Clínica Alma.
2. Al activar el tema se crea la página «Recepción de citas» si el slug
   recepcion-citas está disponible. Si ya existe una página con ese slug,
   no se modifica; revisa el aviso en el administrador y resuelve el conflicto.
3. En Ajustes > Acceso de recepción, configura la contraseña de la cuenta
   independiente «recepcion». El cliente accede mediante «Iniciar sesión»
   en la cabecera; no necesita entrar al administrador de WordPress.
4. Revisa la zona horaria en Ajustes > Generales.

Funcionamiento y límites
-----------------------

La clínica, el personal, los testimonios y los datos de contacto son ficticios;
las fotos son ilustrativas. El contenido de la portada se encuentra en
front-page.php y no se edita desde el editor de páginas de WordPress.

Los formularios guardan solicitudes privadas en la base de datos. Las citas
comparten una agenda: cada solicitud bloquea un horario de 30 minutos, pero no
confirma la cita ni envía notificaciones. Los festivos no se bloquean
automáticamente. Para liberar un horario hay que eliminar definitivamente su
solicitud desde la papelera de WordPress. Las solicitudes anteriores sin horario
no bloquean intervalos.

El ZIP no contiene solicitudes, contraseñas ni otros datos de un sitio previo.
Para migrarlos es necesaria también una copia de la base de datos. Si se cambia
de tema, los datos permanecen, pero la recepción y los formularios no funcionan
sin Clínica Alma.

Antes de publicar, sustituye los datos ficticios y revisa la seguridad, HTTPS,
privacidad, protección contra spam, notificaciones y el proceso de confirmación.
El acceso de recepción es una demostración y no sustituye una auditoría de
seguridad. Usa únicamente datos ficticios mientras se prueba el sitio.

Fotografías ilustrativas de Unsplash: https://unsplash.com/license
Mapa de referencia: © OpenStreetMap, https://www.openstreetmap.org/copyright
