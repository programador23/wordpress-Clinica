<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require dirname(__DIR__, 3) . '/wp-load.php';
$password = base64_decode(trim(stream_get_contents(STDIN)), true);
if ($password === false || strlen($password) < 12 || strlen($password) > 72) {
    fwrite(STDERR, "La contraseña debe tener entre 12 y 72 bytes.\n");
    exit(1);
}
$hash = password_hash($password, PASSWORD_DEFAULT);
if ($hash === false) {
    fwrite(STDERR, "No se pudo proteger la contraseña.\n");
    exit(1);
}
update_option('alma_recepcion_password_hash', $hash, false);
if (get_option('alma_recepcion_password_hash') !== $hash) {
    fwrite(STDERR, "No se pudo guardar la contraseña.\n");
    exit(1);
}
echo "Contraseña de recepción configurada.\n";
