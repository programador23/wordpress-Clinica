<?php
/*
Template Name: Recepción de citas
*/

global $wpdb;
$table = alma_slots_table();
$page = isset($_GET['citas_pagina']) ? max(1, absint($_GET['citas_pagina'])) : 1;
$per_page = 20;
$prefix = $wpdb->esc_like('Cita - ') . '%';
$total = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = %s AND post_title LIKE %s",
    'alma_solicitud',
    'private',
    $prefix
));
$error = $wpdb->last_error;
$appointments = array();
$pages = 0;
if (!$error) {
    $pages = (int) ceil((int) $total / $per_page);
    $page = min($page, max(1, $pages));
    $appointments = $wpdb->get_results($wpdb->prepare(
        "SELECT p.ID, p.post_title, p.post_content, h.horario
         FROM {$wpdb->posts} p
         LEFT JOIN $table h ON h.solicitud_id = p.ID
         WHERE p.post_type = %s AND p.post_status = %s AND p.post_title LIKE %s
         ORDER BY h.horario IS NULL ASC, h.horario DESC, p.ID DESC
         LIMIT %d OFFSET %d",
        'alma_solicitud',
        'private',
        $prefix,
        $per_page,
        ($page - 1) * $per_page
    ));
    $error = $wpdb->last_error;
}
if ($error) {
    error_log('Clínica Alma: no se pudo consultar la recepción de citas.');
}
get_header();
?>
<main id="contenido" class="section">
    <div class="wrap reception">
        <div class="section-heading">
            <div><div class="eyebrow">Acceso privado</div><h1>Recepción de citas</h1><p>Consulta las solicitudes recibidas. El horario queda bloqueado, pero la cita no se confirma automáticamente.</p></div>
            <form method="post" action="<?php echo esc_url(get_permalink()); ?>">
                <input type="hidden" name="recepcion_action" value="salir">
                <input type="hidden" name="recepcion_csrf" value="<?php echo esc_attr($_SESSION['alma_csrf']); ?>">
                <button class="button button-light" type="submit">Cerrar sesión</button>
            </form>
        </div>
        <p class="reception-note">Solo se muestran las solicitudes activas de citas. Los horarios no se confirman automáticamente.</p>
        <?php if ($error) : ?>
            <div class="notice notice-error" role="alert">No se pudieron cargar las citas. Inténtalo nuevamente o consulta los registros del servidor.</div>
        <?php elseif (!$appointments) : ?>
            <div class="form-card"><p>No hay solicitudes de citas para mostrar.</p></div>
        <?php else : ?>
            <div class="reception-list">
                <?php foreach ($appointments as $appointment) : ?>
                    <article class="form-card reception-card">
                        <div class="reception-card-heading">
                            <h2><?php echo esc_html($appointment->post_title); ?></h2>
                            <?php if ($appointment->horario) :
                                $slot = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $appointment->horario, wp_timezone());
                                ?>
                                <span class="reception-date"><?php echo esc_html($slot ? wp_date('d/m/Y · H:i', $slot->getTimestamp()) : $appointment->horario); ?></span>
                            <?php else : ?><span class="reception-date">Sin horario registrado</span><?php endif; ?>
                        </div>
                        <p class="reception-details"><?php echo nl2br(esc_html($appointment->post_content)); ?></p>
                    </article>
                <?php endforeach; ?>
            </div>
            <?php if ($pages > 1) : ?>
                <nav class="reception-pagination" aria-label="Páginas de solicitudes">
                    <?php if ($page > 1) : ?><a class="text-link" href="<?php echo esc_url(add_query_arg('citas_pagina', $page - 1, get_permalink())); ?>">← Anterior</a><?php endif; ?>
                    <span>Página <?php echo esc_html($page); ?> de <?php echo esc_html($pages); ?></span>
                    <?php if ($page < $pages) : ?><a class="text-link" href="<?php echo esc_url(add_query_arg('citas_pagina', $page + 1, get_permalink())); ?>">Siguiente →</a><?php endif; ?>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
