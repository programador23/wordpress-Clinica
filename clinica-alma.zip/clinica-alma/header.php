<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#contenido">Saltar al contenido</a>
<div class="demo-bar">Sitio de demostración · Clínica, profesionales y datos de contacto ficticios</div>
<header class="header">
    <div class="wrap header-inner">
        <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Clínica Alma, inicio"><span class="brand-icon" aria-hidden="true">✳</span><span class="brand-name">alma<small>clínica integral</small></span></a>
        <nav class="nav" aria-label="Navegación principal">
            <a href="<?php echo esc_url(home_url('/#inicio')); ?>">Inicio</a>
            <a href="<?php echo esc_url(home_url('/#nosotros')); ?>">Nosotros</a>
            <a href="<?php echo esc_url(home_url('/#equipo')); ?>">Equipo</a>
            <a href="<?php echo esc_url(home_url('/#servicios')); ?>">Servicios</a>
            <a href="<?php echo esc_url(home_url('/#contacto')); ?>">Contacto</a>
            <a class="button button-light" href="<?php echo esc_url(alma_reception_url()); ?>">Iniciar sesión</a>
            <a class="button" href="<?php echo esc_url(home_url('/#citas')); ?>">Solicitar cita <span aria-hidden="true">↗</span></a>
        </nav>
    </div>
</header>
