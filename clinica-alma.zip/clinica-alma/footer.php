<footer class="footer">
    <div class="wrap">
        <div class="footer-grid">
            <div><a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><span class="brand-icon" aria-hidden="true">✳</span><span class="brand-name">alma<small>clínica integral</small></span></a><p>Un espacio imaginado para cuidarte con cercanía, respeto y atención integral.</p></div>
            <div class="footer-links"><a href="<?php echo esc_url(home_url('/#nosotros')); ?>">Nosotros</a><a href="<?php echo esc_url(home_url('/#servicios')); ?>">Servicios</a><a href="<?php echo esc_url(home_url('/#citas')); ?>">Citas</a><a href="<?php echo esc_url(home_url('/#contacto')); ?>">Contacto</a><a href="<?php echo esc_url(alma_reception_url()); ?>">Acceso a recepción</a></div>
        </div>
        <div class="footer-bottom">© <?php echo esc_html(wp_date('Y')); ?> Clínica Alma · Proyecto de demostración. No es un servicio médico real.</div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
